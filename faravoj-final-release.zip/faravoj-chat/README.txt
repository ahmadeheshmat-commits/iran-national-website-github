اتصال پشتیبانی فراوج به OpenAI — نسخه آماده GitHub + Render

این نسخه برای انتشار روی Render آماده شده است.

### GitHub
1) یک Repository جدید در GitHub بسازید.
2) محتویات همین پوشه `faravoj-chat` را داخل Repository آپلود کنید.
3) فایل `.env` یا کلید OpenAI را هرگز داخل GitHub قرار ندهید.

### Render
1) در Render گزینه New > Web Service را بزنید و Repository را وصل کنید.
2) Runtime: Node
3) Build Command: `npm install`
4) Start Command: `npm start`
5) در Environment Variables این موارد را تنظیم کنید:
   - `OPENAI_API_KEY` = کلید OpenAI
   - `OPENAI_MODEL` = `gpt-5.6-luna`
   - `ADMIN_PASSWORD` = یک رمز قوی و اختصاصی برای پنل ادمین

فایل `render.yaml` همین تنظیمات را هم برای Blueprint/Deploy-as-code تعریف کرده است.

### آدرس
بعد از Deploy، Render یک آدرس `onrender.com` برای سرویس می‌دهد.

### پنل ادمین
پنل از مسیر `/#admin` باز می‌شود و APIهای مدیریتی با رمز `ADMIN_PASSWORD` محافظت شده‌اند. مرورگر برای اولین درخواست مدیریتی پنجره ورود Basic Authentication را نشان می‌دهد؛ نام کاربری را هر چیزی وارد کنید و رمز را همان `ADMIN_PASSWORD` بزنید.

### نکات مهم
- کلید OpenAI فقط روی سرور و در Environment Variables نگهداری می‌شود.
- `conversations.json` روی دیسک سرویس برای تست و استفاده سبک مناسب است؛ دیسک سرویس Render پایدار/دیتابیس نیست و برای استفاده جدی بهتر است PostgreSQL یا دیتابیس مناسب اضافه شود.
- قبل از انتشار عمومی، رمز پنل ادمین را قوی انتخاب کنید.
